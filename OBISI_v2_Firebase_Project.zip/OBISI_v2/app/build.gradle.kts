plugins { id("com.android.application"); id("com.google.gms.google-services") }

android { namespace = "com.obisi.store"; compileSdk = 35
    defaultConfig { applicationId = "com.obisi.store"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "2.0" }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-storage")
    implementation("com.google.firebase:firebase-messaging")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.github.bumptech.glide:glide:4.16.0")
}
